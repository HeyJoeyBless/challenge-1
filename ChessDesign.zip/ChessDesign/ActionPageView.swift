//
//  homePageView.swift
//  ChessDesign
//
//  Created by Joseph Allen Blessman on 10/8/24.
//

import SwiftUI

extension timerPageView {
    final class viewModel: ObservableObject {
        @Published var isActive1 = false
        @Published var isActive2 = false
        @Published var showingAlert1 = false
        @Published var showingAlert2 = false
        @Published var time1: String = "05:00"
        @Published var time2: String = "05:00"
        @Published var minutes: Float = 5.0 {
            didSet {
                self.time1 = "\(Int(minutes)):00"
                self.time2 = "\(Int(minutes)):00"
            }
        }
        
        private var initialTime = 0.0
        private var endDate1 = Date()
        private var endDate2 = Date()
        
        func switchTimer() {
            if isActive1 {
                isActive1 = false
                isActive2 = true
                endDate2 = Calendar.current.date(byAdding: .second, value: Int(timeRemaining(for: endDate1)), to: Date())!
            } else if isActive2 {
                isActive2 = false
                isActive1 = true
                endDate1 = Calendar.current.date(byAdding: .second, value: Int(timeRemaining(for: endDate2)), to: Date())!
            }
        }
        
        func start(minutes: Float) {
            self.initialTime = Double(Int(minutes))
            self.endDate1 = Date()
            self.endDate2 = Date()
            self.isActive1 = true
            self.isActive2 = false
            self.endDate1 = Calendar.current.date(byAdding: .minute, value: Int(minutes), to: endDate1)!
            self.endDate2 = Calendar.current.date(byAdding: .minute, value: Int(minutes), to: endDate2)!
        }
        
        func reset() {
            self.isActive1 = false
            self.isActive2 = false
            self.minutes = Float(initialTime)
            self.time1 = "\(Int(minutes)):00"
            self.time2 = "\(Int(minutes)):00"
        }
        
        private func timeRemaining(for endDate: Date) -> TimeInterval {
            return endDate.timeIntervalSince1970 - Date().timeIntervalSince1970
        }
        
        func updateCountdown() {
            if isActive1 {
                updateTimer(endDate: endDate1, timeBinding: \viewModel.time1, alertBinding: \viewModel.showingAlert1) { self.isActive1 = false }
            } else if isActive2 {
                updateTimer(endDate: endDate2, timeBinding: \viewModel.time2, alertBinding: \viewModel.showingAlert2) { self.isActive2 = false }
            }
        }
        
        private func updateTimer(endDate: Date, timeBinding: ReferenceWritableKeyPath<viewModel, String>, alertBinding: ReferenceWritableKeyPath<viewModel, Bool>, completion: @escaping () -> Void) {
            let diff = timeRemaining(for: endDate)
            
            if diff <= 0 {
                self[keyPath: timeBinding] = "00:00"
                self[keyPath: alertBinding] = true
                completion()
                return
            }
            
            let minutes = Int(diff) / 60
            let seconds = Int(diff) % 60
            self[keyPath: timeBinding] = String(format: "%02d:%02d", minutes, seconds)
        }
    }
}
