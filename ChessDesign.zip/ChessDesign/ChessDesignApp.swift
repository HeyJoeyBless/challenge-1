//
//  ChessDesignApp.swift
//  ChessDesign
//
//  Created by Joseph Allen Blessman on 10/4/24.
//

import SwiftUI

@main
struct ChessDesignApp: App {
    var body: some Scene {
        WindowGroup {
            homePageView()
        }
    }
}


#Preview{
    homePageView()
}
