//
//  homePageView.swift
//  ChessDesign
//
//  Created by Joseph Allen Blessman on 10/8/24.
//

import SwiftUI

struct timerPageView: View {
    @StateObject private var vm = viewModel()
    private let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    private let width: Double = 250
    
    var body: some View {
        ZStack {
            Image("background")
                .resizable()
                .ignoresSafeArea()
            VStack {
                Text("Chess Timer")
                    .font(.system(size: 30, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 5))
                    .frame(width: 379, height: 50)
                    .background(Color.darkblue)
                    .cornerRadius(8)
                    .padding(.top, 50)
                    .offset(y: -115)
                
                VStack(spacing: 20) {
                    Text("P1: \(vm.time1)")
                        .font(.system(size: 70, weight: .medium, design: .rounded))
                        .padding()
                        .frame(width: width)
                        .background(vm.isActive1 ? Color.darkblue.opacity(0.2) : .clear)
                        .cornerRadius(20)
                        .overlay(RoundedRectangle(cornerRadius: 20)
                            .stroke(Color.darkblue, lineWidth: 10))
                    
                    Text("P2: \(vm.time2)")
                        .font(.system(size: 70, weight: .medium, design: .rounded))
                        .padding()
                        .frame(width: width)
                        .background(vm.isActive2 ? Color.darkblue.opacity(0.2) : .clear)
                        .cornerRadius(20)
                        .overlay(RoundedRectangle(cornerRadius: 20)
                            .stroke(Color.darkblue, lineWidth: 10))
                }
                .alert("Timer Done!", isPresented: $vm.showingAlert1) {
                    Button("Continue", role: .cancel) { }
                } message: {
                    Text("Player 1's time is up!")
                }
                .alert("Timer Done!", isPresented: $vm.showingAlert2) {
                    Button("Continue", role: .cancel) { }
                } message: {
                    Text("Player 2's time is up!")
                }
                
                Slider(value: $vm.minutes, in: 1...10, step: 1)
                    .padding()
                    .frame(width: width)
                    .disabled(vm.isActive1 || vm.isActive2)
                    .animation(.easeInOut, value: vm.minutes)
                
                HStack(spacing: 50) {
                    Button("Start") {
                        vm.start(minutes: vm.minutes)
                    }
                    .disabled(vm.isActive1 || vm.isActive2)
                    .buttonStyle(.plain)
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(width: 70, height: 35)
                    .background(Color.darkblue)
                    .cornerRadius(8)
                    
                    Button("Reset", action: vm.reset)
                        .buttonStyle(.plain)
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(width: 70, height: 35)
                        .background(Color.red)
                        .cornerRadius(8)
                    
                    Button("Switch") {
                        vm.switchTimer()
                    }
                    .disabled(!vm.isActive1 && !vm.isActive2)
                    .buttonStyle(.plain)
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(width: 70, height: 35)
                    .background(Color.darkblue)
                    .cornerRadius(8)
                }
                .padding(.top)
            }
            .frame(width: width)
        }
        .onReceive(timer) { _ in
            vm.updateCountdown()
        }
    }
}

#Preview {
    timerPageView()
}
