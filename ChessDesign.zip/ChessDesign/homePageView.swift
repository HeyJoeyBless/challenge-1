//
//  homePageView.swift
//  ChessDesign
//
//  Created by Joseph Allen Blessman on 10/8/24.
//

import SwiftUI

struct homePageView: View {
    var body: some View {
        NavigationStack {
            ZStack {
                Image("background")
                    .resizable()
                    .ignoresSafeArea()
                VStack {
                    Text("Welcome to Mind chess")
                        .font(.system(size: 30, weight: .bold))
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.darkblue)
                        .cornerRadius(8)
                        .padding(.horizontal)
                    
                    Spacer()
                    
                    NavigationLink(destination: skillSetView()) {
                        Text("Play")
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundColor(.white)
                            .frame(width: 70, height: 35)
                            .background(Color.darkblue)
                            .cornerRadius(8)
                    }
                    .buttonStyle(.plain)
                    
                    Spacer()
                }
            }
        }
    }
}

#Preview {
    homePageView()
}
