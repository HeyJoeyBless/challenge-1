//
//  ContentView.swift
//  ChessDesign
//
//  Created by Joseph Allen Blessman on 10/4/24.
//

import SwiftUI

struct skillSetView: View {
    @State var entry: String = ""
    var body: some View {
        @State var isOn = false
        
        ZStack{
            Image("background")
                .resizable()
                .ignoresSafeArea()
            VStack{
                VStack {
                    Text("Select A Skillset!")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundStyle(.white)
                        .frame(height: 40)
                        .padding(.horizontal)
                        .background(Color.darkblue)
                        .cornerRadius(8)
                        .offset(y: -70)
                    
                    NavigationLink(destination: timerPageView()) {
                        Text("Timer")
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundColor(.white)
                            .frame(width: 70, height: 35)
                            .background(Color.darkblue)
                            .cornerRadius(8)
                    }
                    .buttonStyle(.plain)
                }
                .padding(.top, 50)
                
                Spacer()
                
                VStack(spacing: 10) {
                    DisclosureGroup("Beginner") {
                        ScrollView{
                                Text("Just remember to be patient and keep your eye on the board. Take your time, and don't rush. think before you move")
                            
                        }
                        .foregroundStyle(.white)
                        .background(Color.darkblue)
                        .clipShape(RoundedRectangle(cornerRadius: 5))
                    }
                    .foregroundStyle(.darkblue);
                    DisclosureGroup("Intermediate") {
                        ScrollView{
                            Text("Think about your peice Coordination, think about your opponent's peice Coordination, and think about the best move to make. Moves like the Bishop pair, Knight Forks, and Rook Coordination are moves you need to be using to build your game.")
                        }
                        .lineLimit(8)
                        .foregroundStyle(.white)
                        .background(Color.darkblue)
                        .clipShape(RoundedRectangle(cornerRadius: 5))
                    }
                    .foregroundStyle(.darkblue)
                    
                    DisclosureGroup("Tournament Player") {
                        ScrollView{
                            Text("Seize the moment, and play your best game. This is the momment when you take the stage, and show the world what you're made of. remember your training, and your preparation. Your timing matter more than anything now. You're playing for the world, and you're playing for yourself.")
                            }
                        .foregroundStyle(.white)
                        .background(Color.darkblue)
                        .clipShape(RoundedRectangle(cornerRadius: 5))
                        
                        }
                        .foregroundStyle(.darkblue)
                      
                    DisclosureGroup("Club Player") {
                            ScrollView{
                                Text("Piece Coordnation is of course important at this stage. corrdinate your pieces effectively to create threats and control the board. King and Pawn endings can be Over Powered. rememeber and research the three-step rule if  you need to. Rook endings are powerful too. be sure to understand hoe to manuver your rooks to create threats. finally, bishop endings are imporant to remember too. Lone bishop can do more than one can expect.")
                            }
                            .foregroundStyle(.white)
                            .background(Color.darkblue)
                            .clipShape(RoundedRectangle(cornerRadius: 5))
                        }
                        .foregroundStyle(.darkblue);
                        
                    DisclosureGroup("National Player") {
                            ScrollView{
                                Text("I have to find some chess names,books,and videos. when i find them, I will put them here.")
                            }
                            .foregroundStyle(.white)
                            .background(Color.darkblue)
                            .clipShape(RoundedRectangle(cornerRadius: 5))
                        }
                        
                        .foregroundStyle(.darkblue);
                        
                    DisclosureGroup("Candidate Player") {
                            ScrollView{
                                Text("Ill put some annotations here. just to test you later.")
                            }
                            .foregroundStyle(.white)
                            .background(Color.darkblue)
                            .clipShape(RoundedRectangle(cornerRadius: 5))
                        }
                        .foregroundStyle(.darkblue)
                        
                        
                    DisclosureGroup("Personal Notes") {
                            ScrollView{
                                TextField("Annotate Here", text: $entry, axis: .vertical)
                                    .foregroundStyle(.darkblue)
                                    .frame(width:400 , height:400)
                                    .lineLimit(16, reservesSpace: true)
                            }
                            .foregroundStyle(.white)
                            .background(Color.clear)
                            .clipShape(RoundedRectangle(cornerRadius: 5))
                        }
                        .foregroundStyle(.darkblue)
              
                        
                        
                        
                        
                    }
                }
                .padding()
            }
            
            
        }
    }


    #Preview {
        skillSetView()
    }

